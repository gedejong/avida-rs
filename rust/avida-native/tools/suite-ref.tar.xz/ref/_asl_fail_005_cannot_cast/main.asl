float x = { 0 };

